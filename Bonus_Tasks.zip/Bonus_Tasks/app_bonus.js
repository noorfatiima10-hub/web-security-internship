const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');
const validator = require('validator');
const winston = require('winston');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const csrf = require('csurf');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} [${level.toUpperCase()}]: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'security.log' })
  ]
});

const app = express();

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      baseUri: ["'self'"],
      objectSrc: ["'none'"],
    }
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true }
}));

app.use(cors({
  origin: 'http://localhost:3000',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

const csrfProtection = csrf({
  cookie: { httpOnly: true, sameSite: 'strict', secure: false }
});

const users = [];
const JWT_SECRET = 'mysecretkey123';
const revokedTokens = [];

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  handler: (req, res, next, options) => {
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
    res.status(429).send('Too many login attempts. Please try again after 15 minutes.');
  }
});

const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  message: 'Too many signup attempts. Please try again later.',
});

function verifyToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) {
    logger.warn(`Zero Trust: Access denied - no token from IP: ${req.ip}`);
    return res.status(403).json({ error: 'Access denied', message: 'No token provided. Zero Trust policy requires authentication for every request.' });
  }
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : authHeader;
  if (revokedTokens.includes(token)) {
    logger.warn(`Zero Trust: Revoked token used from IP: ${req.ip}`);
    return res.status(401).json({ error: 'Token revoked', message: 'This token has been revoked. Please login again.' });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const now = Math.floor(Date.now() / 1000);
    if (decoded.exp && decoded.exp < now) {
      logger.warn(`Zero Trust: Expired token used by: ${decoded.username}`);
      return res.status(401).json({ error: 'Token expired', message: 'Your token has expired. Please login again.' });
    }
    logger.info(`Zero Trust: Token verified for user: ${decoded.username} from IP: ${req.ip}`);
    req.user = decoded;
    next();
  } catch (err) {
    logger.warn(`Zero Trust: Invalid token from IP: ${req.ip} - ${err.message}`);
    return res.status(401).json({ error: 'Invalid token', message: 'Token verification failed. Access denied.' });
  }
}

app.get('/signup', csrfProtection, (req, res) => {
  res.send(`
    <h2>Signup</h2>
    <form method="POST" action="/signup">
      <input type="hidden" name="_csrf" value="${req.csrfToken()}"/>
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Signup</button>
    </form>
  `);
});

app.post('/signup', csrfProtection, signupLimiter, async (req, res) => {
  const { username, password } = req.body;
  if (!validator.isAlphanumeric(username)) {
    logger.warn(`Invalid signup attempt - bad username: ${username}`);
    return res.send('Invalid username. Only letters and numbers allowed.');
  }
  if (!validator.isLength(password, { min: 6 })) {
    logger.warn(`Invalid signup attempt - password too short for user: ${username}`);
    return res.send('Password must be at least 6 characters.');
  }
  const existingUser = users.find(u => u.username === username);
  if (existingUser) {
    return res.send('Username already exists. Please choose another.');
  }
  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword });
  logger.info(`New user signed up: ${username}`);
  res.send('Signup successful! <a href="/login">Login here</a>');
});

app.get('/login', csrfProtection, (req, res) => {
  res.send(`
    <h2>Login</h2>
    <form method="POST" action="/login">
      <input type="hidden" name="_csrf" value="${req.csrfToken()}"/>
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Login</button>
    </form>
  `);
});

app.post('/login', csrfProtection, loginLimiter, async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) {
    logger.warn(`Failed login - username not found: ${username}`);
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }
  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    logger.warn(`Failed login - wrong password for user: ${username}`);
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }
  const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' });
  logger.info(`Successful login - Zero Trust token issued for: ${username}`);
  res.send(`
    Login successful!<br/><br/>
    <b>Zero Trust Token issued:</b><br/>
    <small>${token}</small><br/><br/>
    <p>This token expires in 1 hour and must be sent with every request.</p>
    <a href="/profile">Go to profile</a>
  `);
});

app.post('/logout', (req, res) => {
  const token = req.headers['authorization'];
  if (token) {
    revokedTokens.push(token);
    logger.info(`Zero Trust: Token revoked on logout from IP: ${req.ip}`);
  }
  res.send('Logged out. Token has been revoked.');
});

app.get('/profile', verifyToken, (req, res) => {
  logger.info(`Zero Trust: Profile accessed by: ${req.user.username}`);
  res.send(`<h2>Profile Page</h2><p>Welcome ${req.user.username}!</p><p>Zero Trust verification passed.</p>`);
});

app.get('/dashboard', verifyToken, (req, res) => {
  logger.info(`Zero Trust: Dashboard accessed by: ${req.user.username}`);
  res.send(`<h2>Dashboard</h2><p>Welcome ${req.user.username}!</p><p>Zero Trust verification passed for dashboard.</p>`);
});

app.listen(3000, () => {
  logger.info('Bonus - Zero Trust Security app started at http://localhost:3000');
});