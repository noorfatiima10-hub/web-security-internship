const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');
const validator = require('validator');
const winston = require('winston');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const csrf = require('csurf');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} [${level.toUpperCase()}]: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'security.log' })
  ]
});

const app = express();

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      baseUri: ["'self'"],
      objectSrc: ["'none'"],
    }
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true }
}));

app.use(cors({
  origin: 'http://localhost:3000',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

const csrfProtection = csrf({
  cookie: { httpOnly: true, sameSite: 'strict', secure: false }
});

const users = [];
const JWT_SECRET = 'mysecretkey123';
const revokedTokens = [];
const blockedIPs = [];

// =============================================
// WAF MIDDLEWARE
// Inspects every incoming request and blocks
// malicious patterns before they reach routes
// =============================================
function waf(req, res, next) {

  // WAF Rule 1: Block known malicious IPs
  if (blockedIPs.includes(req.ip)) {
    logger.warn(`WAF: Blocked request from blacklisted IP: ${req.ip}`);
    return res.status(403).send('Access denied by Web Application Firewall.');
  }

  // WAF Rule 2: Block SQL injection patterns in query and body
  const sqlPatterns = [
    /(\%27)|(\')|(\-\-)|(\%23)|(#)/i,
    /((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/i,
    /\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/i,
    /((\%27)|(\'))union/i,
    /exec(\s|\+)+(s|x)p\w+/i,
    /select.+from/i,
    /insert.+into/i,
    /delete.+from/i,
    /drop.+table/i,
  ];

  const requestData = JSON.stringify(req.body) + JSON.stringify(req.query) + req.url;
  for (const pattern of sqlPatterns) {
    if (pattern.test(requestData)) {
      logger.warn(`WAF: SQL injection attempt blocked from IP: ${req.ip} - Pattern: ${pattern}`);
      return res.status(403).send('Request blocked by Web Application Firewall - SQL injection detected.');
    }
  }

  // WAF Rule 3: Block XSS patterns
  const xssPatterns = [
    /<script[\s\S]*?>[\s\S]*?<\/script>/gi,
    /<[^>]+on\w+\s*=\s*["'][^"']*["']/gi,
    /javascript\s*:/gi,
    /vbscript\s*:/gi,
    /<iframe/gi,
    /<object/gi,
    /<embed/gi,
  ];

  for (const pattern of xssPatterns) {
    if (pattern.test(requestData)) {
      logger.warn(`WAF: XSS attempt blocked from IP: ${req.ip}`);
      return res.status(403).send('Request blocked by Web Application Firewall - XSS detected.');
    }
  }

  // WAF Rule 4: Block path traversal attacks
  const pathTraversalPatterns = [
    /\.\.\//g,
    /\.\.\\/g,
    /%2e%2e%2f/gi,
    /%2e%2e\//gi,
  ];

  for (const pattern of pathTraversalPatterns) {
    if (pattern.test(req.url)) {
      logger.warn(`WAF: Path traversal attempt blocked from IP: ${req.ip}`);
      return res.status(403).send('Request blocked by Web Application Firewall - Path traversal detected.');
    }
  }

  // WAF Rule 5: Block requests with suspicious user agents
  const suspiciousAgents = ['sqlmap', 'nikto', 'nmap', 'masscan', 'zgrab'];
  const userAgent = (req.headers['user-agent'] || '').toLowerCase();
  for (const agent of suspiciousAgents) {
    if (userAgent.includes(agent)) {
      logger.warn(`WAF: Suspicious user agent blocked from IP: ${req.ip} - Agent: ${userAgent}`);
      return res.status(403).send('Request blocked by Web Application Firewall - Suspicious tool detected.');
    }
  }

  // WAF Rule 6: Block oversized request bodies
  const contentLength = parseInt(req.headers['content-length'] || '0');
  if (contentLength > 10000) {
    logger.warn(`WAF: Oversized request blocked from IP: ${req.ip} - Size: ${contentLength}`);
    return res.status(413).send('Request blocked by Web Application Firewall - Request too large.');
  }

  // All checks passed - allow request
  logger.info(`WAF: Request allowed from IP: ${req.ip} - ${req.method} ${req.url}`);
  next();
}

// Apply WAF to ALL routes
app.use(waf);

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  handler: (req, res, next, options) => {
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
    res.status(429).send('Too many login attempts. Please try again after 15 minutes.');
  }
});

const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  message: 'Too many signup attempts. Please try again later.',
});

function verifyToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) {
    logger.warn(`Zero Trust: Access denied - no token from IP: ${req.ip}`);
    return res.status(403).json({ error: 'Access denied', message: 'No token provided.' });
  }
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : authHeader;
  if (revokedTokens.includes(token)) {
    logger.warn(`Zero Trust: Revoked token used from IP: ${req.ip}`);
    return res.status(401).json({ error: 'Token revoked', message: 'Please login again.' });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    logger.info(`Zero Trust: Token verified for user: ${decoded.username}`);
    req.user = decoded;
    next();
  } catch (err) {
    logger.warn(`Zero Trust: Invalid token from IP: ${req.ip}`);
    return res.status(401).json({ error: 'Invalid token', message: 'Access denied.' });
  }
}

app.get('/signup', csrfProtection, (req, res) => {
  res.send(`
    <h2>Signup</h2>
    <form method="POST" action="/signup">
      <input type="hidden" name="_csrf" value="${req.csrfToken()}"/>
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Signup</button>
    </form>
  `);
});

app.post('/signup', csrfProtection, signupLimiter, async (req, res) => {
  const { username, password } = req.body;
  if (!validator.isAlphanumeric(username)) {
    logger.warn(`Invalid signup attempt - bad username: ${username}`);
    return res.send('Invalid username. Only letters and numbers allowed.');
  }
  if (!validator.isLength(password, { min: 6 })) {
    logger.warn(`Invalid signup attempt - password too short for user: ${username}`);
    return res.send('Password must be at least 6 characters.');
  }
  const existingUser = users.find(u => u.username === username);
  if (existingUser) {
    return res.send('Username already exists. Please choose another.');
  }
  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword });
  logger.info(`New user signed up: ${username}`);
  res.send('Signup successful! <a href="/login">Login here</a>');
});

app.get('/login', csrfProtection, (req, res) => {
  res.send(`
    <h2>Login</h2>
    <form method="POST" action="/login">
      <input type="hidden" name="_csrf" value="${req.csrfToken()}"/>
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Login</button>
    </form>
  `);
});

app.post('/login', csrfProtection, loginLimiter, async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) {
    logger.warn(`Failed login - username not found: ${username}`);
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }
  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    logger.warn(`Failed login - wrong password for user: ${username}`);
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }
  const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' });
  logger.info(`Successful login - token issued for: ${username}`);
  res.send(`
    Login successful!<br/><br/>
    Your token: <b>${token}</b><br/><br/>
    <a href="/profile">Go to profile</a>
  `);
});

app.get('/profile', verifyToken, (req, res) => {
  logger.info(`Profile accessed by: ${req.user.username}`);
  res.send(`<h2>Profile Page</h2><p>Welcome ${req.user.username}!</p><p>WAF and Zero Trust verification passed.</p>`);
});

app.listen(3000, () => {
  logger.info('Bonus 2 - WAF enabled app started at http://localhost:3000');
});