const express = require('express');
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const users = [];

// Signup page
app.get('/signup', (req, res) => {
  res.send(`
    <h2>Signup</h2>
    <form method="POST" action="/signup">
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Signup</button>
    </form>
  `);
});

// Signup logic
app.post('/signup', (req, res) => {
  const { username, password } = req.body;
  users.push({ username, password });
  res.send('Signup successful! <a href="/login">Login here</a>');
});

// Login page
app.get('/login', (req, res) => {
  res.send(`
    <h2>Login</h2>
    <form method="POST" action="/login">
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Login</button>
    </form>
  `);
});

// Login logic
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    res.send(`Welcome ${username}! <a href="/profile">Go to profile</a>`);
  } else {
    res.send('Invalid credentials. <a href="/login">Try again</a>');
  }
});

// Profile page
app.get('/profile', (req, res) => {
  res.send('<h2>Profile Page</h2><p>You are logged in.</p>');
});

app.listen(3000, () => {
  console.log('App running at http://localhost:3000');
});