# GitHub Submission Checklist
**Student:** Noor Fatima | **Date:** April 27, 2026

---

## STEP 1 — Prepare Your Files Locally

### Code Files
- [ ] `app.js` — secure final version with all fixes applied
- [ ] `app_old.js` — original vulnerable version saved for comparison
- [ ] `package.json` — exists in your myapp folder already
- [ ] `security.log` — generated when you run the app

### Screenshots Folder
Create a folder called `screenshots` inside `myapp` and add these:
- [ ] `xss_popup.png` — the XSS alert popup from Week 1 testing
- [ ] `xss_blocked.png` — "Invalid username" message after fix
- [ ] `password_short.png` — "Password must be at least 6 characters" message
- [ ] `jwt_token.png` — login page showing JWT token
- [ ] `headers_before.png` — DevTools showing X-Powered-By and missing headers
- [ ] `headers_after.png` — DevTools showing all security headers present
- [ ] `winston_logs.png` — Command Prompt showing all log entries

### Documents
- [ ] `Security_Assessment_Report_Noor_Fatima.docx` — your full report
- [ ] `README.md` — your README file

---

## STEP 2 — Create GitHub Repository

- [ ] Go to https://github.com and sign in (or create a free account)
- [ ] Click the **+** button at the top right
- [ ] Click **New repository**
- [ ] Name it something like: `web-security-internship`
- [ ] Set it to **Public**
- [ ] Do NOT initialize with README (you already have one)
- [ ] Click **Create repository**

---

## STEP 3 — Upload Your Files to GitHub

Open Command Prompt and run these commands one by one:

```bash
cd C:\Users\Noor Fatima\myapp
```

```bash
git init
```

```bash
git add .
```

```bash
git commit -m "Initial commit — security assessment project"
```

```bash
git branch -M main
```

```bash
git remote add origin https://github.com/[YOUR-USERNAME]/web-security-internship.git
```

```bash
git push -u origin main
```

> Replace [YOUR-USERNAME] with your actual GitHub username

---

## STEP 4 — Verify Your GitHub Repository

Go to your GitHub repo and confirm these are all there:

- [ ] `app.js` is visible
- [ ] `app_old.js` is visible
- [ ] `package.json` is visible
- [ ] `README.md` is visible and renders correctly on the repo homepage
- [ ] `screenshots/` folder is visible with all images inside
- [ ] `Security_Assessment_Report_Noor_Fatima.docx` is uploaded
- [ ] `security.log` is visible

---

## STEP 5 — Commit Messages Checklist

Make sure your commit history shows meaningful messages. You can make separate commits for each week:

- [ ] `Week 1 — vulnerable app setup and testing`
- [ ] `Week 2 — security fixes applied`
- [ ] `Week 3 — winston logging added`
- [ ] `Final — report and README added`

---

## STEP 6 — Record Your Video

Your video should cover these points in order:

- [ ] Briefly introduce yourself and explain the assignment (30 seconds)
- [ ] Show the vulnerable app running — demonstrate the XSS popup
- [ ] Show the SQL injection test — explain why it did not work
- [ ] Show the plain text password code in app_old.js
- [ ] Show the response headers before fix in DevTools
- [ ] Switch to the secure app — show XSS is now blocked
- [ ] Show the JWT token appearing after login
- [ ] Show the response headers after fix in DevTools
- [ ] Show the Winston logs in Command Prompt
- [ ] Show your GitHub repository with all files uploaded
- [ ] Briefly summarize what you learned (30 seconds)

**Recommended free recording tools:**
- OBS Studio — https://obsproject.com (free, no watermark)
- Xbox Game Bar — press Windows + G (built into Windows 11)

---

## STEP 7 — Final Submission Check

Go through this final list before submitting:

### Code
- [ ] app.js runs without errors using `node app.js`
- [ ] All 3 pages work: /signup, /login, /profile
- [ ] XSS is blocked on the secure version
- [ ] JWT token appears after login
- [ ] Security headers visible in DevTools
- [ ] Winston logs appear in terminal

### Report
- [ ] All 14 sections are filled in
- [ ] All screenshot placeholders replaced with real screenshots
- [ ] Before/after comparison table is complete
- [ ] Your name and date are on the cover page

### GitHub
- [ ] Repository is public
- [ ] README renders correctly
- [ ] All files are uploaded
- [ ] At least 3-4 meaningful commit messages

### Video
- [ ] Video covers all key demonstrations
- [ ] Video is uploaded to YouTube, Google Drive, or as instructed
- [ ] Link is included in your submission

---

## Quick Summary — What You Built

| Week | What You Did |
|------|-------------|
| Week 1 | Built vulnerable app, found XSS, plain text passwords, missing headers |
| Week 2 | Fixed XSS with validator, hashed passwords with bcrypt, added JWT auth, added helmet |
| Week 3 | Added Winston logging, verified all fixes, prepared report and README |

---

> You are done! Great work completing the full 3-week assignment. 🎉
