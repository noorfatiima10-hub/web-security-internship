const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} [${level.toUpperCase()}]: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'security.log' })
  ]
});



const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');
const validator = require('validator');

const app = express();

// FIX 1: Helmet adds all missing security headers
app.use(helmet());

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const users = [];
const JWT_SECRET = 'mysecretkey123';

// Middleware to verify JWT token
function verifyToken(req, res, next) {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(403).send('Access denied. No token provided.');
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).send('Invalid token.');
  }
}

// Signup page
app.get('/signup', (req, res) => {
  res.send(`
    <h2>Signup</h2>
    <form method="POST" action="/signup">
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Signup</button>
    </form>
  `);
});

// Signup logic
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;

  // FIX 2: Validate input using validator
  if (!validator.isAlphanumeric(username)) {
    return res.send('Invalid username. Only letters and numbers allowed.');
  }
  if (!validator.isLength(password, { min: 6 })) {
    return res.send('Password must be at least 6 characters.');
  }

  // FIX 3: Hash password using bcrypt before storing
  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword });

  res.send('Signup successful! <a href="/login">Login here</a>');
});

// Login page
app.get('/login', (req, res) => {
  res.send(`
    <h2>Login</h2>
    <form method="POST" action="/login">
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Login</button>
    </form>
  `);
});

// Login logic
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  const user = users.find(u => u.username === username);
  if (!user) {
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }

  // FIX 4: Compare password with bcrypt hash
  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }

  // FIX 5: Create JWT token on successful login
  const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' });
  res.send(`
    Login successful!<br/><br/>
    Your token: <b>${token}</b><br/><br/>
    <a href="/profile">Go to profile</a>
  `);
});

// Profile page - FIX 6: Protected with JWT verification
app.get('/profile', verifyToken, (req, res) => {
  res.send(`<h2>Profile Page</h2><p>Welcome ${req.user.username}!</p>`);
});

app.listen(3000, () => {
  console.log('Secure app running at http://localhost:3000');
});