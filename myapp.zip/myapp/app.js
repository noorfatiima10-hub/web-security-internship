const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');
const validator = require('validator');
const winston = require('winston');

// Logger setup
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} [${level.toUpperCase()}]: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'security.log' })
  ]
});

const app = express();

app.use(helmet());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const users = [];
const JWT_SECRET = 'mysecretkey123';

// JWT verification middleware
function verifyToken(req, res, next) {
  const token = req.headers['authorization'];
  if (!token) {
    logger.warn('Profile access denied - no token provided');
    return res.status(403).send('Access denied. No token provided.');
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    logger.warn('Profile access denied - invalid token');
    return res.status(401).send('Invalid token.');
  }
}

// Signup page
app.get('/signup', (req, res) => {
  res.send(`
    <h2>Signup</h2>
    <form method="POST" action="/signup">
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Signup</button>
    </form>
  `);
});

// Signup logic
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;

  if (!validator.isAlphanumeric(username)) {
    logger.warn(`Invalid signup attempt - bad username: ${username}`);
    return res.send('Invalid username. Only letters and numbers allowed.');
  }
  if (!validator.isLength(password, { min: 6 })) {
    logger.warn(`Invalid signup attempt - password too short for user: ${username}`);
    return res.send('Password must be at least 6 characters.');
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword });
  logger.info(`New user signed up: ${username}`);
  res.send('Signup successful! <a href="/login">Login here</a>');
});

// Login page
app.get('/login', (req, res) => {
  res.send(`
    <h2>Login</h2>
    <form method="POST" action="/login">
      <input name="username" placeholder="Username"/><br/><br/>
      <input name="password" type="password" placeholder="Password"/><br/><br/>
      <button type="submit">Login</button>
    </form>
  `);
});

// Login logic
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  const user = users.find(u => u.username === username);
  if (!user) {
    logger.warn(`Failed login attempt - username not found: ${username}`);
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }

  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    logger.warn(`Failed login attempt - wrong password for user: ${username}`);
    return res.send('Invalid credentials. <a href="/login">Try again</a>');
  }

  const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' });
  logger.info(`Successful login: ${username}`);
  res.send(`
    Login successful!<br/><br/>
    Your token: <b>${token}</b><br/><br/>
    <a href="/profile">Go to profile</a>
  `);
});

// Profile page - protected
app.get('/profile', verifyToken, (req, res) => {
  logger.info(`Profile accessed by: ${req.user.username}`);
  res.send(`<h2>Profile Page</h2><p>Welcome ${req.user.username}!</p>`);
});

// App start
app.listen(3000, () => {
  logger.info('Secure app started at http://localhost:3000');
});